package com.wipro.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.springboot.entity.Order;

public interface IOrderRepository extends JpaRepository<Order, Integer> {

	List<Order> findByCategory(String category);
}
