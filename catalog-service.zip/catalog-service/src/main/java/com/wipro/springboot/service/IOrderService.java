package com.wipro.springboot.service;

import java.util.List;

import com.wipro.springboot.entity.Order;

public interface IOrderService {

	public List<Order> getOrders();

	public List<Order> getOrdersByCategory(String category);

	public void initOrdersTable();
}
