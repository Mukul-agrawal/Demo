package com.wipro.springboot.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.springboot.entity.Order;
import com.wipro.springboot.repository.IOrderRepository;

@Service
public class OrderServiceImpl implements IOrderService {

	@Autowired
	private IOrderRepository orderRepository;

	@Override
	public List<Order> getOrders() {
		return orderRepository.findAll();
	}

	@Override
	public List<Order> getOrdersByCategory(String category) {
		return orderRepository.findByCategory(category);
	}

	@Override
	public void initOrdersTable() {
		orderRepository.saveAll(Stream
				.of(new Order("mobile", "electronics", "white", 20000), new Order("T-Shirt", "clothes", "black", 999),
						new Order("Jeans", "clothes", "blue", 1999), new Order("Laptop", "electronics", "gray", 50000),
						new Order("digital watch", "electronics", "black", 2500),
						new Order("Fan", "electronics", "black", 50000))
				.collect(Collectors.toList()));
	}

}
