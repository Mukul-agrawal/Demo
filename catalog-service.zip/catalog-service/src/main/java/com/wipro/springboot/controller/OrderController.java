package com.wipro.springboot.controller;

import java.util.List;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.springboot.entity.Order;
import com.wipro.springboot.service.IOrderService;

@RestController
@RequestMapping("/Order")
public class OrderController {

	@Autowired
	private IOrderService orderService;

	@PostConstruct
	public void initOrdersTable() {
		orderService.initOrdersTable();
	}

	@GetMapping("/orders")
	public List<Order> getOrders() {
		return orderService.getOrders();
	}

	@GetMapping("/orders/{category}")
	public List<Order> getOrdersByCategory(@PathVariable("category") String category) {
		return orderService.getOrdersByCategory(category);
	}
}
